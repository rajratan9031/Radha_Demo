var currentPage = 'pageObjPage';

module.exports = function() {

      this.Given(/^I login to (.*)$/, function (env, callback) {
		env = browser.params.login.url;
          pageObjPage.getLogin(env).then(function (completed) {
			browser.ignoreSynchronization = true;
			assert.isTrue(completed, 'Not login page');
			callback();
		});
	});

    this.When(/^I authenticate with valid (.*) and (.*)$/, function (userName, password, callback) {
        userName = browser.params.login.username;
        password = browser.params.login.password;
        pageObjPage.setName(userName).then(function () {
            pageObjPage.setPassword(password).then(function () {
                pageObjPage.clickLogin().then(function () {
                    callback();
                });
            });
        });
    });
	
	    this.Given(/^I go to url$/, function (callback) {
        browser.ignoreSynchronization = true;
        pageObjPage.get().then(function(){
			browser.sleep(8000);
            //analysisPage.getUserName().then(function () {
                callback();
            //});
        })

    });

	
 this.Given(/^The application is authenticated$/, function (callback) {
        browser.ignoreSynchronization = true;
        browser.driver.get("http://www.globalsqa.com/angularJs-protractor/BankingProject/#/login").then(function () {
        browser.sleep(8000);
		callback();
        });
    });
    this.Then(/^I can validate Customer Login field$/, function (callback) {
        browser.ignoreSynchronization = true;
		pageObjPage.waitForCustomerLoginBtn().then(function () {
			//element(by.xpath("//*[@class='btn btn-primary btn-lg'][text()='Customer Login']")).isPresent().then(function () {
				browser.sleep(8000);
                        callback();
        });
    });
	
	this.Then(/^I can able to click on Customer login button$/, function(callback) {
          pageObjPage.customerLoginBtn().then(function() {
                 callback();
                });
         });
    /*this.Then(/^I can able to click on Customer login button$/, function (callback) {
		//pageObjPage.customerLoginBtn().then(function () {
        element(by.xpath("//*[@class='btn btn-primary btn-lg'][text()='Customer Login']")).click().then(function () {
            browser.sleep(8000);
			callback();
        });
    });*/

    this.Given(/^I can select your Name$/, function (callback) {
        pageObjPage.yourNameSelection().then(function () {
			browser.sleep(8000);
            callback();
        });
    });
	
	 this.Then(/^I can click on Login button$/, function (callback) {
        pageObjPage.loginBtn().then(function () {
            callback();
        });
    });
	
	 this.Then(/^I can click on Transactions button$/, function (callback) {
        pageObjPage.transactionBtn().then(function () {
            callback();
        });
    });





};
